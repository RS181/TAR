# Cloud
Projecto realizado no âmbito da cadeira Administração de Sistemas Cloud


## Arquitetura

![image](https://github.com/user-attachments/assets/cb907d1a-e12a-46bd-b146-f328cfb461d3)
